







<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $portadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<aside class="responsive-banner">
  <div class="container-envelope">
      <img class="img-responsive" src="<?php echo e(asset('img/'. $portada->imagen)); ?>" alt="portada" width="100%">
  </div>
</aside>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="container">
<h1 class="new-title">Nuestros servicios</h1>
    <div class="carrusel-robots2 bx-viewport subcategoria">    

        <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card" style="padding: 40px">
          <h3 class="card-title new-title-card"><?php echo e($imagen->title); ?></h3>
          <div class="card-body">
            <img class="card-img-top img-responsive" src="<?php echo e(asset('img/services/'. $imagen->imagen)); ?>" alt="portada" width="100%">
            <p class="card-text new-title-text"><?php echo e($imagen->description); ?></p>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saul\resources\views/Servicios/index.blade.php ENDPATH**/ ?>