



<?php $__env->startSection('content'); ?>
<h2>Gestion de Quienes somos</h2>

<?php if( count($portadas) == 0): ?>
<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal" id="open"><i class="fa fa-plus"></i> Crear</button>
<?php endif; ?>
    <div class="row">
        <?php $__currentLoopData = $portadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="margin-bottom: 40px;margin-top: 40px" class="col-12 col-lg-6">
            <img src="<?php echo e(asset('img/aboutus/'. $portada->imagen)); ?>" alt="..." style="width:100%;height:120px">
            <strong>Fecha de creacion:</strong> <?php echo e($portada->created_at); ?> <br>
            <strong>Usuario editor:</strong> admin <br>
            <strong>Fecha de edicion:</strong> <?php echo e($portada->updated_at); ?> <br>
            <strong>Misión:</strong> <?php echo e($portada->mision); ?> <br>
            <strong>Visión:</strong> <?php echo e($portada->vision); ?> <br>
            <button class="btn btn-success btn-sm"> <i class="fa fa-eye"></i></button>
            <button class="btn btn-danger btn-sm" type="button"  data-toggle="modal" data-target="#myModal1<?php echo e($portada->id); ?>" id="open"><i class="fa fa-trash"></i></button>
            <form method="post" action="<?php echo e(route('aboutus.destroy', ['aboutu' => $portada])); ?>" id="form1" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
              <!-- Modal -->
              <div class="modal" tabindex="-1" role="dialog" id="myModal1<?php echo e($portada->id); ?>">
              <div class="modal-dialog" role="document">
              <div class="modal-content">
              <div class="alert alert-danger" style="display:none"></div>
              <div class="modal-header">
                
                <h5 class="modal-title"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <h3 class="text-center">¿Esta seguro de eliminar?</h3>
              </div>
              <div class="modal-footer">
                <button  class="btn btn-primary" id="ajaxSubmit1">Si</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
                </div>
              </div>
              </div>
              </div>
              </form>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <form method="post" action="aboutus" id="form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    <!-- Modal -->
    <div class="modal" tabindex="-1" role="dialog" id="myModal">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="alert alert-danger" style="display:none"></div>
      <div class="modal-header">
        
        <h5 class="modal-title">Crear Quienes somos</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
            <div class="form-group col-md-8">
              <label for="img">imagen:</label>
              <input type="file" name="img" id="img">
            </div>
          </div>
          <div class="row">
            <div class="form-group col-md-8">
            <label for="state">Misión:</label>
            <textarea name="mision" id="" cols="40" rows="5"></textarea>
          </div>
        </div>
          <div class="row">
            <div class="form-group col-md-8">
            <label for="state">Visión:</label>
            <textarea name="vision" id="" cols="40" rows="5"></textarea>
      </div>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">cerrar</button>
        <button  class="btn btn-success" id="ajaxSubmit">Crear</button>
        </div>
    </div>
    </div>
    </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saul\resources\views/admin/Quienes/index.blade.php ENDPATH**/ ?>