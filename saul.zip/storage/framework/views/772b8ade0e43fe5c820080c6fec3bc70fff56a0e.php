






<?php $__env->startSection('content'); ?>
  <div id="carouselExampleControls" class="carousel slide img-portada-height" data-ride="carousel">
  <div class="carousel-inner img-portada-height">
  <?php $__currentLoopData = $portadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $portada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="img-portada-height item  <?php echo e(( $key == 0) ? 'active' : ''); ?>">
      <img class="img-responsive d-block w-100 img-portada" src="<?php echo e(asset('img/portadas/'. $portada->imagen)); ?>" alt="portada">
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
  <div class="wrap mcb-wrap one col-centrar column-margin-0px valign-top clearfix" style="background-color:#00b600">
    <div class="mcb-wrap-inner">
      <div class="column-ventas">
        <div class="hover_box">
          <a href="https://ventasctsaul.com/" target="_blank">
            <div class="hover_box_wrapper">
              <img style="width: 100%;height: 100px;" class="visible_photo scale-with-grid" src="<?php echo e(asset('img/Compra.png')); ?>" alt="Compra">
            </div>
          </a>
        </div>
      </div>
    </div>
  </div>

  <section class="new-collections opposite-background col-12">
    <h3 class="animated wow zoomIn animated title-section" data-wow-delay=".5s">CATEGORÍAS</h3>
    
    <div class="row mx-auto justify-content-center align-items-center">
      <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-6 col-md-4 col-lg-3">
        <div class="img-category p-3 border">
          <a href="http://127.0.0.1:8000/catalogo?category=<?php echo e($categoria->title); ?>">
            <img class="img-responsive" src="<?php echo e(asset('img/categorias/'. $categoria->imagen)); ?>" alt="categoria">
            <div class="text-block-image">
              <h4 class="text-upper"><?php echo e($categoria->title); ?></h4>
            </div>
          </a>
        </div>
    </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>

  <section class="new-collections col-12">
    <h3 class="animated wow zoomIn animated title-section" data-wow-delay=".5s">Destacados</h3>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="carrusel-robots bx-viewport subcategoria">    
        <?php $__currentLoopData = $productsDes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productDes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="thumbnail productoStyle img-category">
        <a href="https://ventasctsaul.com/Productos/Ver/233" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Lector de huella digital "><img class="imagenR img-responsive" src="<?php echo e(asset('img/productos/'.$productDes->category .'/'.$productDes->imagen)); ?>" alt="<?php echo e($productDes->title); ?>"></a>
            <div class="caption text-center">
                <i class="fas fa-people-carry"></i>
                <i class="fas fa-truck"></i>
              </div>
              <div class="caption borderS">
                <h6 class="text-center productoText">
                    <a href="https://ventasctsaul.com/Productos/Ver/233"><?php echo e($productDes->title); ?> </a>
                </h6>
              </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>
   

<section class="new-collections col-12 opposite-background">
  <h3 class="animated wow zoomIn animated title-section" data-wow-delay=".5s">Productos nuevos</h3>
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    
    <div class="carrusel-robots bx-viewport subcategoria">
      <?php $__currentLoopData = $productsNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="thumbnail productoStyle">
        <a href="https://ventasctsaul.com/Productos/Ver/233" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Lector de huella digital "><img class="imagenR img-responsive" src="<?php echo e(asset('img/productos/'.$productNew->category .'/'.$productNew->imagen)); ?>"></a>
        <div class="caption text-center">
            <i class="fas fa-people-carry"></i>
            <i class="fas fa-truck"></i>
          </div> 
            <div class="caption borderS">
                <h6 class="text-center productoText">
                    <a href="https://ventasctsaul.com/Productos/Ver/233"><?php echo e($productNew->title); ?> </a>
                </h6>
              </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

</section>
<?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <section class="new-collections col-12 opposite-background">
    <h3 class="animated wow zoomIn animated title-section" data-wow-delay=".5s"><?php echo e($seccion->title); ?></h3>
        
    <?php if($seccion->type == 0): ?>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      
      <div class="carrusel-robots bx-viewport subcategoria">
        <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($seccion->id == $imagen->seccion_id): ?>
          <div class="thumbnail productoStyle">
            <a href="https://ventasctsaul.com/Productos/Ver/233" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Lector de huella digital "><img class="imagenR img-responsive" src="<?php echo e(asset('img/seccion/'.$imagen->category .'/'.$imagen->imagen)); ?>"></a>
            <div class="caption text-center">
              <i class="fas fa-people-carry"></i>
              <i class="fas fa-truck"></i>
            </div> 
            <div class="caption borderS">
              <h6 class="text-center productoText">
                <a href="https://ventasctsaul.com/Productos/Ver/233"><?php echo e($imagen->title); ?> </a>
              </h6>
            </div>
          </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>    
    <?php else: ?>
    <div class="row mx-auto justify-content-center align-items-center">
      <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($seccion->id == $imagen->seccion_id): ?>

      <div class="col-6 col-md-4 col-lg-3">
        <div class="img-category p-3 border">
          <a href="https://ventasctsaul.com/Productos/Ver/233">
            <img class="img-responsive" src="<?php echo e(asset('img/seccion/'. $imagen->imagen)); ?>" alt="categoria">
            <div class="text-block-image">
              <h4 class="text-upper"><?php echo e($imagen->title); ?></h4>
            </div>
          </a>
        </div>
    </div>
     <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
  </section>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <section style="margin-top: 30px">
    <div class="row" style="margin-right: 0px;margin-left: 0px;">
        
<div class="offset-5 col-2"></div>
        <div class="col-12 col-lg-4 text-center">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FCT-Saul-532296690259418%2F&tabs=timeline&width=340&height=300&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="100%" height="400" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
        </div>
    </div>
 </section>

 <section class="new-collections brands col-12 opposite-background">
  <h3 class="animated wow zoomIn animated title-section" data-wow-delay=".5s">Nuestros Clientes</h3>
  <div class="carrusel-robots1 mt-3" style="width: 100%; overflow: hidden; position: relative; height: 155px;">
    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div style="float: left; list-style: none; position: relative; width: 200px; margin-right: 50px;"><img class="img-responsive" src="<?php echo e(asset('img/clients/'.$client->imagen)); ?>"  alt="Robot 1"/></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>  
 </section>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saul\resources\views/index.blade.php ENDPATH**/ ?>