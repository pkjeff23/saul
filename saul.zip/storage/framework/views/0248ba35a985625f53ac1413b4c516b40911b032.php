







<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $portadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<aside class="responsive-banner">
  <div class="container-envelope">
      <img class="img-responsive" src="<?php echo e(asset('img/aboutus/'. $portada->imagen)); ?>" alt="portada" width="100%">
  </div>
</aside>
<hr>
<div class="container">
  <div class="row">
  <div class="col">
    <div class="document">
      <div class="header">
        <h1 class="title">Misión</h1>
      </div> 
      <div class="content">
        <?php echo e($portada->mision); ?>

        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <div class="document">
          <div class="header">
            <h1 class="title">Visión</h1>
          </div> 
          <div class="content">
            <?php echo e($portada->vision); ?>

            </div>
        </div>
      </div>
    </div>
</div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saul\resources\views/Quienes/index.blade.php ENDPATH**/ ?>