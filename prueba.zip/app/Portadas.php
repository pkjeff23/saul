<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Portadas extends Model
{
    protected $fillable = [
        'state', 'imagen'
    ];
}
