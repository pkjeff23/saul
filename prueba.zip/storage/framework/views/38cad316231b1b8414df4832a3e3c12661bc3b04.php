<?php
    $isIndex = false;

    $hasButtonBack = true;
    $hasButtonAdd = false;
    $hasButtonDel = true;
    $hasButtonSave = true;
?>


    


    <?php $__env->startSection('title', 'Actualizar usuario'); ?>


    <?php $__env->startSection('form_method', 'POST'); ?>
    <?php $__env->startSection('form_action', route('users.update', $user)); ?>
    <?php $__env->startSection('form_laravelCsrf', csrf_field()); ?>
    <?php $__env->startSection('form_laravelMethod', method_field('PUT')); ?>

        <?php $__env->startSection('name_value', old('name', $user->name)); ?>
        <?php $__env->startSection('name_disabled', ''); ?>

        <?php $__env->startSection('email_value', old('email', $user->email)); ?>
        <?php $__env->startSection('email_disabled', ''); ?>
        
        <?php $__env->startSection('password_value', old('password', $user->password)); ?>
        <?php $__env->startSection('password_disabled', ''); ?>

        <?php $__env->startSection('role_value', old('role', )); ?>
        <?php $__env->startSection('role_disabled', ''); ?>


    <?php $__env->startSection('buttonAdd_disabled', 'disabled'); ?>

    <?php $__env->startSection('buttonDel_disabled', ''); ?>

        <?php $__env->startSection('HTML-formDelete'); ?>
            <form id="formDelete"
                method="POST"
                action="<?php echo e(route('users.destroy', $user)); ?>"
                >
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

            </form>
        <?php $__env->stopSection(); ?>

    <?php $__env->startSection('buttonSave_formType', 'submit'); ?>
    <?php $__env->startSection('buttonSave_formId', 'form'); ?>
    <?php $__env->startSection('buttonSave_disabled', ''); ?>
<?php echo $__env->make('users.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/users/edit.blade.php ENDPATH**/ ?>