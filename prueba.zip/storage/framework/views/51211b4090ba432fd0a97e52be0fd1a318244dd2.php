

    





<?php $__env->startSection('content'); ?>
<h2>hola</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.clients.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/admin/clientes/index.blade.php ENDPATH**/ ?>