







<?php $__env->startSection('content'); ?>
<div class="row" style="margin-top: 40px;margin-right: 0px;margin-left: 0px;">
  <div class="col-md-3">
    <div class="panel panel-default">
      <div class="panel-heading" style="background-color: #003c94;color: white;">CATEGORIAS</div>
      <div class="panel-body">
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h4 class="text-upper bt-enlace1" onclick="myFunction1('<?php echo e($categoria->title); ?>')"><span class="fa fa-check" style="color:#4CAF50"></span> <?php echo e($categoria->title); ?></h4>
            <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($categoria->title == $prueba): ?>
                <?php if($categoria->id == $subcategoria->category_id): ?>
                  <h6 class="text-upper bt-enlace1" onclick="myFunction2('<?php echo e($subcategoria->title); ?>')"><span class="fa fa-check" style="color:#4CAF50; margin-left: 15px"></span> <?php echo e($subcategoria->title); ?></h6>
                <?php endif; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <div class="col-md-9">
  <div class="panel panel-default">
  <div class="panel-heading" style="background-color: #003c94;color: white;">PRODUCTOS</div>
  
  <div class="panel-body">
  
  <div class="row">
    <?php $__currentLoopData = $portadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="item col-xs-6 col-lg-4">
  <div class="thumbnail">
    <a onclick="window.location='<?php echo e(route('catalogo.show', $portada->id)); ?>'"><img class="imagenR group list-group-image pruebaimg" src="<?php echo e(asset('img/productos/'.$portada->category .'/'.$portada->imagen)); ?>" alt="" /></a>
  <div class="caption">
  <h4 class="group inner list-group-item-heading" style="text-overflow:ellipsis; overflow:hidden; white-space: nowrap;">
  <?php echo e($portada->title); ?></h4>
  <p class="group inner list-group-item-text">
  <?php echo e($portada->desciption); ?></p>
  <div class="row">
  <div class="col-xs-12 col-md-6">
  </div>
  </div>
  </div>
  </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <p>
  <?php echo e($portadas->total()); ?> registros |
  páginas <?php echo e($portadas->currentPage()); ?>

  de <?php echo e($portadas->lastPage()); ?>

  </p>
  
  <?php echo e($portadas->links()); ?>

  </div>
  </div>
  </div>
  </div>
  </div>
  <script type = "text/javascript" language = "javascript">
    function myFunction1(p1) {
      window.location = "catalogo?category="+ p1;
    }
    function myFunction2(p1) {
      window.location = "catalogo?subcategory="+ p1;
    }
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/Catalogo/index.blade.php ENDPATH**/ ?>