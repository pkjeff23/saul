



    <?php $__env->startSection('title', 'Clients'); ?>


    <?php $__env->startSection('HTML-cssVendors'); ?>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('HTML-css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/Clients.css')); ?>">
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('HTML-jsVendors'); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('HTML-js'); ?>
        <script type="text/javascript" language="javascript" src="<?php echo e(asset('js/clients.js')); ?>"></script>
    <?php $__env->stopSection(); ?>


<?php $__env->startSection('HTML-main'); ?>
    <div class="row">
        <?php if($isIndex == true): ?>
            <div class="col-md-7">
                <table class="table">
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Dni</th>
                        <th>Email</th>
                        <th>Direccion</th>
                        <th></th>
                    </tr>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($client->id); ?></td>
                            <td><?php echo e($client->name); ?></td>
                            <td><?php echo e($client->dni); ?></td>
                            <td><?php echo e($client->email); ?></td>
                            <td><?php echo e($client->address); ?></td>
                            <td class="text-right">
                                <button class="btn btn-outline-dark btn-sm"
                                    title="Editar"
                                    onclick="window.location='<?php echo e(route('clients.edit', $client)); ?>'"
                                    >
                                    <i class="fas fa-pencil-alt"></i>
                                </button>

                                <form class="formDelete"
                                    method="POST"
                                    action="<?php echo e(route('clients.destroy', $client)); ?>"
                                    >
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>


                                    <button class="btn btn-outline-danger btn-sm"
                                        type="button"
                                        data-toggle="modal"
                                        data-target="#myModal<?php echo e($client->id); ?>"
                                        >
                                        <i class="fas fa-trash"></i>
                                    </button>

                                    <div class="modal fade"
                                        id="myModal<?php echo e($client->id); ?>"
                                        tabindex="-1"
                                        role="dialog"
                                        aria-labelledby="myModalLabel">

                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button"
                                                        class="close"
                                                        data-dismiss="modal"
                                                        aria-label="Close"><span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                                <div class="modal-body">
                                                    ¿Está seguro de eliminar éste cliente?
                                                </div>

                                                <div class="modal-footer">
                                                    <button id="buttonDel"
                                                        class="btn btn-danger"
                                                        type="submit"
                                                        alt="Eliminar"
                                                    >Si</button>

                                                    <button type="button"
                                                        class="btn btn-primary"
                                                        data-dismiss="modal"
                                                    >No</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>

            <div class="col-md-5">
                <h3 class="text-center rb-4">Crear Cliente</h3>

                <form method="post" action="<?php echo e(route('clients.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <input type="text" 
                            name="name" 
                            id="name" 
                            class="form-control" 
                            placeholder="Nombre cliente" 
                            required
                        >
                    </div>

                    <div class="form-group">
                        <input type="number" 
                            name="dni" 
                            id="dni" 
                            class="form-control" 
                            placeholder="Documento de identidad" 
                            required
                        >
                    </div>

                    <div class="form-group">
                        <input type="email" 
                            name="email" 
                            id="email" 
                            class="form-control" 
                            placeholder="Email" 
                            required
                        >
                    </div>

                    <div class="form-group">
                        <input type="text" 
                            name="address" 
                            id="address" 
                            class="form-control" 
                            placeholder="Direccion" 
                            required
                        >
                    </div>

                    <button type="submit" class="btn btn-success btn-block">Crear cliente</button>
                </form>

                <?php if(session('agregar')): ?>
                    <div class="alert alert-success mt-3">
                        <?php echo e(session('agregar')); ?>

                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div id="formsFrm" class="col-12">
                <form id="form"
                    method="<?php echo $__env->yieldContent("form_method"); ?>"
                    action="<?php echo $__env->yieldContent("form_action"); ?>"
                    >
                    <?php echo $__env->yieldContent("form_laravelCsrf"); ?>
                    <?php echo $__env->yieldContent("form_laravelMethod"); ?>

                    <?php if($errors->any()): ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="alert alert-danger" role="alert">
                                    <strong>Novedades</strong>

                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div id="nameFrm" class="form-row form-group">
                        <div class="col-12 col-lg-2 text-right">
                            <label for="clients_id" class="col-form-label">Nombre</label>
                        </div>

                        <div class="col-12 col-lg-3">
                            <input type="text" 
                                name="name" 
                                id="name" 
                                class="form-control" 
                                placeholder="Nombre cliente"
                                value="<?php echo $__env->yieldContent('name_value'); ?>" 
                                required
                            >
                        </div>
                    </div>

                    <div id="dniFrm" class="form-row form-group">
                        <div class="col-12 col-lg-2 text-right">
                            <label for="dni" class="col-form-label">Dni</label>
                        </div>

                        <div class="col-12 col-lg-3">
                            <input type="text" 
                                name="dni" 
                                id="dni" 
                                class="form-control" 
                                placeholder="Nombre cliente"
                                value="<?php echo $__env->yieldContent('dni_value'); ?>" 
                                required
                            >
                        </div>
                    </div>

                    <div id="emailFrm" class="form-row form-group">
                        <div class="col-12 col-lg-2 text-right">
                            <label for="email" class="col-form-label">Email</label>
                        </div>

                        <div class="col-12 col-lg-3">
                            <input type="text" 
                                name="email" 
                                id="email" 
                                class="form-control" 
                                placeholder="Nombre cliente"
                                value="<?php echo $__env->yieldContent('email_value'); ?>" 
                                required
                            >
                        </div>
                    </div>

                    <div id="addressFrm" class="form-row form-group">
                        <div class="col-12 col-lg-2 text-right">
                            <label for="address" class="col-form-label">Direccion</label>
                        </div>

                        <div class="col-12 col-lg-3">
                            <input type="text" 
                                name="address" 
                                id="address" 
                                class="form-control" 
                                placeholder="Nombre cliente"
                                value="<?php echo $__env->yieldContent('address_value'); ?>" 
                                required
                            >
                        </div>
                    </div>
                </form>
            </div>

                <?php echo $__env->yieldContent('HTML-formDelete'); ?>
            </div>

            <div id="buttonsFrm" class="form-row form-group">
                <div class="col-1">
                    <?php if($hasButtonBack == true): ?>
                        <button id="buttonBack" class="btn btn-light btn-link"
                            onclick="window.location='<?php echo e(route('clients.index')); ?>';"
                        >Regresar</button>
                    <?php endif; ?>
                </div>

                <div class="offset-2 offset-lg-1 col-1">
                    <?php if($hasButtonSave == true): ?>
                        <button class="btn btn-dark"
                            type="<?php echo $__env->yieldContent('buttonSave_formType'); ?>"
                            form="<?php echo $__env->yieldContent('buttonSave_formId'); ?>"
                            <?php echo $__env->yieldContent('buttonSave_disabled'); ?>
                        >Guardar</button>
                    <?php endif; ?>
                </div>

                <div class="offset-5 col-1 offset-lg-8 col-lg-1">
                    <?php if($hasButtonDel == true): ?>
                        <button class="btn btn-danger"
                            type="button"
                            data-toggle="modal"
                            data-target="#myModal"
                            <?php echo $__env->yieldContent('buttonDel_disabled'); ?>
                        >Eliminar</button>

                        <div class="modal fade"
                            id="myModal"
                            tabindex="-1"
                            role="dialog"
                            aria-labelledby="myModalLabel">

                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button"
                                            class="close"
                                            data-dismiss="modal"
                                            aria-label="Close"><span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>

                                    <div class="modal-body">
                                        Esta seguro de eliminar ?
                                    </div>

                                    <div class="modal-footer">
                                        <button class="btn btn-danger"
                                            type="submit"
                                            form="formDelete"
                                        >Si</button>

                                        <button type="button"
                                            class="btn btn-primary"
                                            data-dismiss="modal"
                                        >No</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/clients/layout.blade.php ENDPATH**/ ?>