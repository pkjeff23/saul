<?php
    $isIndex = true;

    $hasButtonBack = false;
    $hasButtonAdd = true;
    $hasButtonDel = false;
    $hasButtonSave = false;
?>


    


    <?php $__env->startSection('title', ''); ?>


    <?php $__env->startSection('buttonAdd_disabled', ''); ?>
<?php echo $__env->make('users.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/users/index.blade.php ENDPATH**/ ?>