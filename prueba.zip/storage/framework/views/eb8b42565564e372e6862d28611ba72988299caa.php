







<?php $__env->startSection('content'); ?>
<h2>Gestion de Secciones</h2>
<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal" id="open"><i class="fa fa-plus"></i> Crear</button>
<div class="row" >
  <?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div style="margin-bottom: 40px;margin-top: 40px" class="col-12 col-lg-4">
    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($seccion->id == $imagen->seccion_id): ?>
        <button class="btn btn-outline" style="margin-top: 4px" data-toggle="modal" data-target="#myModal3<?php echo e($imagen->id); ?>" id="open"> <img src="<?php echo e(asset('img/seccion/'. $imagen->imagen)); ?>" alt="..." style="width:60px;height:50px"></button>        
        <?php endif; ?>
        <form style="display: inline" method="post" action="<?php echo e(route('seccionesimg.update', ['seccionesimg' => $imagen])); ?>"  enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
        <!-- Modal -->
        <div class="modal" tabindex="-1" role="dialog" id="myModal3<?php echo e($imagen->id); ?>">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="alert alert-danger" style="display:none"></div>
        <div class="modal-header">
          
          <h5 class="modal-title">Actualizar imagen seccion</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="form-group offset-2 col-md-10">
              <img src="<?php echo e(asset('img/seccion/'.$imagen->imagen)); ?>" width="80%" alt="Robot 1"/>
            </div>
          </div>
            <div class="row">
                <div class="form-group col-md-8">
                  <label for="img">imagen:</label>
                  <input type="file" name="img" id="img">
                </div>
              </div>
            <div class="row">
                <div class="form-group col-md-8">
                  <label for="title">titulo:</label>
                <input style="border: 1px solid #ced4da;!important" type="hidden" class="form-control" name="seccion_id" value=<?php echo e($seccion->id); ?>>
                <input style="border: 1px solid #ced4da;!important" type="hidden" class="form-control" name="imagen" value=<?php echo e($imagen->imagen); ?>>
                  <input style="border: 1px solid #ced4da;!important" type="text" class="form-control" name="title" id="title" value=<?php echo e($imagen->title); ?>>
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">cerrar</button>
          <button  class="btn btn-success">Actualizar</button>
          </div>
        </div>
        </div>
        </div>
        </form>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div style="display: block"></div>
      <strong >Fecha de creacion:</strong> <?php echo e($seccion->created_at); ?> <br>
      <strong>Usuario editor:</strong> admin <br>
      <strong>Fecha de edicion:</strong> <?php echo e($seccion->updated_at); ?> <br>
      <strong>Tipo:</strong> <?php echo e((1 == $seccion->type) ? 'Recuadro' : 'carousell'); ?> <br>
      <strong>Estado:</strong> <?php echo e((1 == $seccion->state) ? 'Activo' : 'Inactivo'); ?> <br>
      
        <button class="btn btn-success btn-sm"type="button"  data-toggle="modal" data-target="#myModal2<?php echo e($seccion->id); ?>" id="open"> <i class="fa fa-plus"></i></button>
        <button class="btn btn-danger btn-sm" type="button"  data-toggle="modal" data-target="#myModal1<?php echo e($seccion->id); ?>" id="open"><i class="fa fa-trash"></i></button>
      <form method="post" action="<?php echo e(url('seccionesimg')); ?>" id="form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    <!-- Modal -->
    <div class="modal" tabindex="-1" role="dialog" id="myModal2<?php echo e($seccion->id); ?>">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="alert alert-danger" style="display:none"></div>
      <div class="modal-header">
        
        <h5 class="modal-title">Crear imagen para seccion</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="row">
              <div class="form-group col-md-8">
                <label for="title">Titulo imagen:</label>
                <input style="border: 1px solid #ced4da;!important" type="hidden" class="form-control" name="seccion_id" value=<?php echo e($seccion->id); ?>>
                <input style="border: 1px solid #ced4da;!important" type="text" class="form-control" name="title" id="title">
              </div>
          </div>
          <div class="row">
            <div class="form-group col-md-8">
              <label for="img">imagen:</label>
              <input type="file" name="img" id="img">
              <label for="prueba" style="color: red;">El tamaño minimo de la imagen debe ser de 240 x 300 px</label>
            </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">cerrar</button>
        <button  class="btn btn-success" id="ajaxSubmit">Crear</button>
        </div>
    </div>
    </div>
    </div>
    </form>
      <form method="post" action="<?php echo e(route('secciones.destroy', ['seccione' => $seccion] )); ?>" id="form1" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
        <!-- Modal -->
        <div class="modal" tabindex="-1" role="dialog" id="myModal1<?php echo e($seccion->id); ?>">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="alert alert-danger" style="display:none"></div>
        <div class="modal-header">
          
          <h5 class="modal-title"></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <h3 class="text-center">¿Esta seguro de eliminar esta seccion?</h3>
        </div>
        <div class="modal-footer">
          <button  class="btn btn-primary">Si</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
          </div>
        </div>
        </div>
        </div>
        </form>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <form method="post" action="<?php echo e(url('secciones')); ?>" id="form">
        <?php echo csrf_field(); ?>
    <!-- Modal -->
    <div class="modal" tabindex="-1" role="dialog" id="myModal">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="alert alert-danger" style="display:none"></div>
      <div class="modal-header">
        
        <h5 class="modal-title">Crear seccion</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="row">
              <div class="form-group col-md-8">
                <label for="title">Titulo seccion:</label>
                <input style="border: 1px solid #ced4da;!important" type="text" class="form-control" name="title" id="title">
              </div>
          </div>
          <div class="row">
            <div class="form-group col-md-8">
               <label for="type">tipo:</label>
               <select style="border: 1px solid #ced4da;!important" class="form-control" name="type" id="type">
                <option value=1>Recuadros</option>
                <option value=0>Carousell</option>
               </select>
             </div>
         </div>
          <div class="row">
             <div class="form-group col-md-8">
                <label for="state">Estado:</label>
                <select style="border: 1px solid #ced4da;!important" class="form-control" name="state" id="state">
                  <option value=1>activo</option>
                  <option value=0>inactivo</option>
                </select>
              </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">cerrar</button>
        <button  class="btn btn-success" id="ajaxSubmit">Crear</button>
        </div>
    </div>
    </div>
    </div>
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/admin/secciones/index.blade.php ENDPATH**/ ?>